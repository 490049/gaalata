"""
 Dummy Offline

 @results     one result
 @stable      yes
"""


def search(query, request_params):
    return [{
        'result': 'this is what you get',
    }]
