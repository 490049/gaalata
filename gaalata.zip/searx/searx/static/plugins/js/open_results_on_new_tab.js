$(document).ready(function() {
    $('.result_header > a').attr('target', '_blank');
});
